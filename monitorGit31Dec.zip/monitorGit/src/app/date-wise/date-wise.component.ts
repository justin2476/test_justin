import { Component, OnInit } from '@angular/core';
import {DashboardComponent} from '../dashboard/dashboard.component';
@Component({
  selector: 'app-date-wise',
  templateUrl: './date-wise.component.html',
  styleUrls: ['./date-wise.component.css']
})
export class DateWiseComponent implements OnInit {
workData:any;
dailyCount:any;
fullName:any;
  constructor() { }

  ngOnInit() {
    this.fullName=localStorage.getItem('fullName');
    this.workData=JSON.parse(localStorage.getItem("workData") || "[]");
  //  let obj;
  this.dailyCount=[]

    this.workData.forEach(element => {
      const day =new Date(element.createdDate)
     const date=day.getDate();
     const fullDate=day.getDate()+'/'+day.getMonth()+'/'+day.getFullYear();


      const c = this.dailyCount.map(e => e.day).indexOf(date);
      console.log(c);
      if (c === -1) {
        const count = 1;
        let obj = {
          day: date,
          name: this.fullName,
          fullDate:fullDate,
          date:day,
          count
        };
        this.dailyCount.push(obj);
      }
      else {
        this.dailyCount[c].count += 1;
      }


    });
    console.log(this.dailyCount)
  }

  edit(cust){

    alert(cust.date);
  }

}
