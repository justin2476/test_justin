// import { Component, OnInit } from '@angular/core';

// @Component({
  // selector: 'app-date-picker',
  // templateUrl: './date-picker.component.html',
  // styleUrls: ['./date-picker.component.css']
// })
// export class DatePickerComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }

import {Component} from '@angular/core';
import {NgbDate, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-date-picker',
  templateUrl: './date-picker.component.html',
  styleUrls: ['./date-picker.component.css']
  
})
export class DatePickerComponent {

  hoveredDate: NgbDate;

  fromDate: NgbDate;
  toDate: NgbDate;

  constructor(calendar: NgbCalendar) {
    this.fromDate = calendar.getToday();
    this.toDate = calendar.getNext(calendar.getToday(), 'd', 5);
    var fromDateString='';
fromDateString=fromDateString+this.fromDate.year+'-'+this.dateFix(this.fromDate.month)+'-'+this.dateFix(this.fromDate.day)+"T18:30:00.00Z"
var toDateString='';
toDateString=toDateString+this.toDate.year+'-'+this.dateFix(this.toDate.month)+'-'+this.dateFix(this.toDate.day)+"T18:30:00.00Z"
localStorage.setItem('fromDate',fromDateString);
localStorage.setItem('toDate',toDateString);
  }
  dateFix(dates) {
    if(dates<10)
    dates='0'+dates
    return dates
        }
  onDateSelection(date: NgbDate) {
    if (!this.fromDate && !this.toDate) {
      this.fromDate = date;
    } else if (this.fromDate && !this.toDate && date.after(this.fromDate)) {
      this.toDate = date;
    } else {
      this.toDate = null;
      this.fromDate = date;
    }

    
  if(this.fromDate){
var fromDateString='';
fromDateString=fromDateString+this.fromDate.year+'-'+this.dateFix(this.fromDate.month)+'-'+this.dateFix(this.fromDate.day)+"T18:30:00.00Z"
localStorage.setItem('fromDate',fromDateString);

if(this.toDate)
{
var toDateString='';
toDateString=toDateString+this.toDate.year+'-'+this.dateFix(this.toDate.month)+'-'+this.dateFix(this.toDate.day)+"T18:30:00.00Z"
localStorage.setItem('toDate',toDateString);
}
  }
  }

  isHovered(date: NgbDate) {
    return this.fromDate && !this.toDate && this.hoveredDate && date.after(this.fromDate) && date.before(this.hoveredDate);
  }

  isInside(date: NgbDate) {
    return date.after(this.fromDate) && date.before(this.toDate);
  }

  isRange(date: NgbDate) {
    return date.equals(this.fromDate) || date.equals(this.toDate) || this.isInside(date) || this.isHovered(date);
  }


}

