import { Component, OnInit, Injectable } from '@angular/core';
 
import {SignupService} from '../signup.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
@Injectable()
export class DashboardComponent implements OnInit {
  display = false;
  apiData: object;
  newData = [];
  totalData: any;
  dailyCount = [];
  newUser:any;
  fromDate=new Date();
  workData:any;
  constructor(private apiService: SignupService) { }

  async ngOnInit() {

    var fromDateString='';
    fromDateString=fromDateString+this.fromDate.getFullYear()+'-'+this.dateFix(this.fromDate.getMonth()+1)+'-'+this.dateFix(this.fromDate.getDate())+"T18:30:00.00Z"
    this.totalData= await this.apiToGetWork(fromDateString)
 
    this.countWork();
  }
apiToGetUser(mobile){
  return new Promise(resolve=>{
  this.apiService.getUser(mobile).subscribe(user => {resolve(user)});
  })

}
dateFix(dates) {
  if(dates<10)
  dates='0'+dates
  return dates
      }
apiToGetWork(fromDate){
  return new Promise(resolve=>{
    this.apiService.getWorkDate(fromDate).subscribe(data => {

     resolve( data);
  
    } );
  })

}
 async onClick() {
    if (this.display === false) {
this.display = true;
    } else {
  console.log(localStorage.getItem('fromDate'));
  this.totalData= await this.apiToGetWork(localStorage.getItem('fromDate'))
 
    this.countWork();
  

  this.display = false;
}
}

edit(cust) {
   this.workData=[]
  localStorage.setItem("fullName",cust.name);
  this.totalData.forEach( (item) => {
    if(item.mobile==cust.mobile)
    {
      this.workData.push(item);
    }
  })
  console.log(this.workData)
  localStorage.setItem("workData",JSON.stringify(this.workData));

}


  private countWork() {
    let distinctMobile = [];
    let fullName = "";
    let obj ={};
    this.dailyCount=[]
    this.totalData.forEach(async (item) => {
      if (distinctMobile.indexOf(item.mobile) == -1) {
        this.newUser = await this.apiToGetUser(item.mobile);
        fullName = this.newUser.firstName + " " + this.newUser.lastName;
      }
      const c = this.dailyCount.map(e => e.mobile).indexOf(item.mobile);
      console.log(c);
      if (c === -1) {
        distinctMobile.push(item.mobile);
        const count = 1;
         obj = {
          mobile: item.mobile,
          name: fullName,
          count
        };
        this.dailyCount.push(obj);
      }
      else {
        this.dailyCount[c].count += 1;
      }
    });
  }
}
