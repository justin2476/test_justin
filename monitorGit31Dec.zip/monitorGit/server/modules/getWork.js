var workPage = require('../model/workPage');
async function getWork(apiData) {
    return new Promise((resolve, reject) => {
        var query = {};
        console.log(apiData)
        if (apiData.medId)
            query.medId = apiData.medId;
        if (apiData.userId) {
            query.userId = apiData.userId;
        } if (apiData.type) {
            query.type = apiData.type;
        }
        if (apiData.mobile) {
            query.mobile = apiData.mobile;
        }


if(apiData.startDate)
        var start = new Date(apiData.startDate);
        else
        var start = new Date();
        start.setDate(start.getDate()-1);
        start.setHours(0, 0, 0, 0);
       // var end = new Date();
        query.createdDate = { $gt:start };
        // obj.endTime = { $lt: new Date(end) };
        console.log(query)

        var pageNo = parseInt(apiData.pageNo)
        if (apiData.size)
            var size = parseInt(apiData.size)
        else
            var size = 5
        var skipLimit = {}
        // if (pageNo > 0 && pageNo != 0 && pageNo) {
        //     skipLimit.skip = size * (pageNo - 1)
        // }
        // skipLimit.limit = size
        // skipLimit.sort = {
        //     _id: -1 //Sort by Date Added DESC
        // }
        //schema.find(query,projection,skip limit,callback function)
        workPage.find(query, {}, skipLimit, function (err, doc) {
            if (err)
                reject(err);
            resolve(doc);
        });
    })

}
module.exports = { 'getWork': getWork }
