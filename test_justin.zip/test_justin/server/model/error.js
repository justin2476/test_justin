const responseData={
    status : Boolean,
    body :{
        message:String
        },
    error:{
        statusCode:Error,
        message:String
        }
    }
    
module.exports ={"responseData":responseData}