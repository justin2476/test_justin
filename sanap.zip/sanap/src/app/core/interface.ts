export interface IUser {
        userId:string;
        firstName:string;
        lastName:string;
        password:string;
        mobile:number;        
}
