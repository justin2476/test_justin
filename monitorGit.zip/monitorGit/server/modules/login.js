var user = require('../model/user');
var md5 = require('md5');
const {genrateResponse}=require('../model/genrateResponse');
async function Login(ObjQuerry) {

    return new Promise((resolve, reject) => {
        var access = genrateResponse("access denied",false);
        var obj = {};
        obj.mobile = "";
        obj.password = "";
        if (ObjQuerry.mobile) {

            var obj = {"mobile":ObjQuerry.mobile,"login.password":ObjQuerry.password};

          
            console.log(obj); 
        }
        else
            resolve(access);
            
            console.log("going to findOne"); 

        user.findOne(obj).exec(function (err, doc) {
            console.log("in the findOne "+err+", "+doc); 

            if (err)
                {console.log(err)
                    resolve(genrateResponse(err,false));
                 console.log(doc)
                }
            var access = genrateResponse("access denied",false)
            if (doc) {
                if (obj.mobile)
                    if (doc.mobile == obj.mobile && doc.password == obj.password)
                        var access =genrateResponse(doc.role,true);
                console.log(doc.mobile);
            }
            resolve(access);
        });
    })

}
module.exports = { 'Login': Login }
