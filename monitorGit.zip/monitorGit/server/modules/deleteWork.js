


var WorkPage = require('../model/workPage');
const { genrateResponse } = require("../model/genrateResponse");
var mongoose = require('mongoose');
var deleteWork = async function (data) {
  return new Promise((resolve, reject) => {

  var responseData={};
  console.log('in put api '+data)
     //responseData.responseData="Issue";

    // var conditions = { "_id":data.medId}
    // , update = { $set: {"medId":data.newMed,"action":data.action,"status":data.status, "comment": data.comment }}
    // , options = { multi: true };
  
    // WorkPage.updateMany(conditions, update, options, callback);

    WorkPage.deleteOne({"medId":data.medId}, callback);

  
  function callback (err, numAffected) {
    // numAffected is the number of updated documents
    console.log("In save")
    if (err)
        {console.log("error in saving " + err)
        responseData=genrateResponse("error while saving "+err,false);
        resolve(responseData)
      }
        else {
        console.log("Data Saved for user " + JSON.stringify( numAffected))
        //responseData=numAffected;
        responseData =genrateResponse(numAffected,true)

        resolve(responseData)

    }
    console.log("response " + JSON.stringify( responseData))
  }
  
  })
}

module.exports = { 'deleteWork': deleteWork }
