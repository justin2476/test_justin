const mongoose = require('mongoose');

const schema = mongoose.Schema;
ObjectId = schema.ObjectId;
const config = new schema({
    _id: ObjectId,
    configName: String,
    configId:String,
    firstName: String,
    lastName: String,  
    mobile: String,
    accountStatus:Boolean,
    role:String,
    login: {
        password: String,
        locked: Boolean,
        updatedDate:Date
    },
    createdDate: Date,
    updatedDate: Date
})
module.exports = mongoose.model("config", config, "config");

//mongoose.model("name of model","name of schema","collection to save")
