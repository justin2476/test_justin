
const mongoose = require('mongoose');

const schema = mongoose.Schema;
ObjectId = schema.ObjectId;
const work = new schema({
    _id: ObjectId,
    medId: String,
    action: String,
    status: String,
    comment: String,
    mobile: String,
    createdDate: Date,
    updatedDate: Date,
    point:Number
})
module.exports = mongoose.model("work", work, "work");

