function genrateResponse(msg, status) {
    var response = {
        status: Boolean,
        body: {
            message: String
        },
        error: {
            statusCode: String,
            message: String
        }
    };
    if (status === false) {
        response.status = false;
        response.error.statusCode = 300;
        response.error.message = msg;
    }
    else {
        response.status = true;
        response.body.message = msg;
    }
    return response;
}    
exports.genrateResponse = genrateResponse;