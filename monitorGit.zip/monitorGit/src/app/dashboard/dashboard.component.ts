import { Component, OnInit, Injectable } from '@angular/core';
import { Route, Router } from '@angular/router';


import {SignupService} from '../signup.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
@Injectable()
export class DashboardComponent implements OnInit {
  display = false;
  apiData: object;
  newData = [];
  totalData: any;
  dailyCount = [];
  newUser:any;
  fromDate:any=new Date();
  toDisplayDate=new Date();
  workData:any;
  adminFlag:string;
  constructor(private apiService: SignupService, private router :Router) { }

  async ngOnInit() {
    this.adminFlag = sessionStorage.getItem('isAdmin');
    if (this.adminFlag != 'true') {
      alert( 'Please login as admin' );
      this.router.navigate(['/']);
    }
    else{
if(localStorage.getItem('fromDate'))
{
  console.log("fromlocalstorage "+localStorage.getItem('fromDate'))
  this.toDisplayDate=new Date(localStorage.getItem('fromDate'));
  this.fromDate=this.toDisplayDate;
  var fromDateString='';
    fromDateString=fromDateString+this.fromDate.getFullYear()+'-'+this.dateFix(this.fromDate.getMonth()+1)+'-'+this.dateFix(this.fromDate.getDate())+"T00:00:00.00Z"
    this.totalData= await this.apiToGetWork(fromDateString)
  // alert("if "+c )
    this.countWork();
}
else
{
  this.toDisplayDate=new Date();
  this.fromDate=this.toDisplayDate;
  var fromDateString='';
  fromDateString=fromDateString+this.fromDate.getFullYear()+'-'+this.dateFix(this.fromDate.getMonth()+1)+'-'+this.dateFix(this.fromDate.getDate())+"T00:00:00.00Z"
  this.totalData= await this.apiToGetWork(fromDateString)
// alert("if "+c )
  this.countWork();
}
    }
//     let count=localStorage.getItem("totalData");
//     if(count=='[]')
//     {
//     var fromDateString='';
//     fromDateString=fromDateString+this.fromDate.getFullYear()+'-'+this.dateFix(this.fromDate.getMonth()+1)+'-'+this.dateFix(this.fromDate.getDate())+"T18:30:00.00Z"
//     this.totalData= await this.apiToGetWork(fromDateString)
//   // alert("if "+c )
//     this.countWork();

//   }
//   else
//    { 
//      this.totalData=JSON.parse(count || "[]");
//      this.countWork();

//  // alert(this.dailyCount)
 
//   }
  }
apiToGetUser(mobile){
  return new Promise(resolve=>{
  this.apiService.getUser(mobile).subscribe(user => {resolve(user)});
  })

}
dateFix(dates) {
  if(dates<10)
  dates='0'+dates
  return dates
      }
apiToGetWork(fromDate){
  return new Promise(resolve=>{
    this.apiService.getWorkDate(fromDate).subscribe(data => {

     resolve( data);
  
    } );
  })

}
 async onClick() {
    if (this.display === false) {
this.display = true;
    } else {

      this.fromDate=localStorage.getItem('fromDate');
      this.toDisplayDate=new Date(this.fromDate);

  console.log(this.fromDate);
  this.totalData= await this.apiToGetWork(this.fromDate)
  localStorage.setItem("totalData",JSON.stringify(this.totalData));

    this.countWork();
  

  this.display = false;
}
}

edit(cust) {
   this.workData=[]
  localStorage.setItem("fullName",cust.name);
  this.totalData.forEach( (item) => {
    if(item.mobile==cust.mobile)
    {
      this.workData.push(item);
    }
  })
  let averageCount=cust.count/cust.dateCount.length
  localStorage.setItem("averageCount",averageCount.toString());
  let averagePoint=cust.point/cust.dateCount.length
  localStorage.setItem("averagePoint",averagePoint.toString());
  console.log(this.workData)
  localStorage.setItem("workData",JSON.stringify(this.workData));
  

}


  private countWork() {
    let distinctMobile = [];
    let fullName = "";
    let obj ={};
    this.dailyCount=[]
    this.totalData.forEach(async (item) => {
      if (distinctMobile.indexOf(item.mobile) == -1) {
        this.newUser = await this.apiToGetUser(item.mobile);
        fullName = this.newUser.firstName + " " + this.newUser.lastName;
      }
      var day=new Date(item.createdDate);
    //  let dateCount=[];
      const c = this.dailyCount.map(e => e.mobile).indexOf(item.mobile);
      // console.log(c);
      if (c === -1) {
        distinctMobile.push(item.mobile);
        const count = 1;
     
        obj = {
          mobile: item.mobile,
          name: fullName,
          count,
          point:item.point,
          dateCount:[day.getDate()]

        };
        this.dailyCount.push(obj);
      }
      else {
        this.dailyCount[c].count += 1;
        this.dailyCount[c].point += item.point;
        if(this.dailyCount[c].dateCount.indexOf(day.getDate())==-1)
            this.dailyCount[c].dateCount.push(day.getDate());
      }
      // console.log(this.dailyCount);
     // alert("localStorage saved "+localStorage.getItem("dailyCount") )
    });

  }
}
