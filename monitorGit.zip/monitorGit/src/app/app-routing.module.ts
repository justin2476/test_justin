import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {SignupComponent} from './signup/signup.component';
import {TableComponent} from './table/table.component';
import {LoginComponent} from './login/login.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import {DateWiseComponent} from './date-wise/date-wise.component';
import {DayWorkComponent} from './day-work/day-work.component';

import { from } from 'rxjs';


const routes: Routes = [
  {
    path: '',
    component: LoginComponent
  },
  {
    path: 'signup',
    component: SignupComponent
  },
  {
    path: 'table',
    component: TableComponent
  },
  {
    path: 'dashboard',
    component: DashboardComponent
  },
  {
    path: 'DateWise',
    component: DateWiseComponent
  },
  {
    path: 'dayWork',
    component: DayWorkComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
