import { Component, OnInit } from '@angular/core';
import {DashboardComponent} from '../dashboard/dashboard.component';
import {Router} from '@angular/router';
@Component({
  selector: 'app-date-wise',
  templateUrl: './date-wise.component.html',
  styleUrls: ['./date-wise.component.css']
})
export class DateWiseComponent implements OnInit {
workData:any;
dailyCount:any;
fullName:any;
averageCount=localStorage.getItem('averageCount');
averagePoint=localStorage.getItem('averagePoint');
  constructor(private router: Router) { }

  ngOnInit() {
    this.fullName=localStorage.getItem('fullName');
    this.workData=JSON.parse(localStorage.getItem("workData") || "[]");
  //  let obj;
  this.dailyCount=[]

    this.workData.forEach(element => {
      const day =new Date(element.createdDate)
     const date=day.getDate();
     const fullDate=day.getDate()+'/'+(day.getMonth()+1)+'/'+day.getFullYear();


      const c = this.dailyCount.map(e => e.day).indexOf(date);
      console.log(c);
      if (c === -1) {
        const count = 1;
        let obj = {
          day: date,
          name: this.fullName,
          fullDate:fullDate,
          date:day,
          count,
          point:element.point
        };
        this.dailyCount.push(obj);
      }
      else {
        this.dailyCount[c].count += 1;
        this.dailyCount[c].point += element.point;
      }


    });
    console.log(this.dailyCount)
  }

  edit(cust){
let fullData=[];
    //alert(cust.date);
    this.workData.forEach(element => {
     var checkDate= new Date(element.createdDate);
     console.log("from element "+checkDate.getDate());
     console.log("from cust "+cust.date.getDate());
     if(checkDate.getDate()==cust.date.getDate())
     {
      fullData.push(element)


     }

    })
   localStorage.setItem("fullData",JSON.stringify(fullData))

   this.router.navigate(['/dayWork']);


  }

}
