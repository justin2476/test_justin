import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day-work',
  templateUrl: './day-work.component.html',
  styleUrls: ['./day-work.component.css']
})
export class DayWorkComponent implements OnInit {
  dailyCount:any;
  fullName:any;
  constructor() { }

  ngOnInit() {
    this.dailyCount=JSON.parse(localStorage.getItem("fullData") || "[]");
    this.fullName=localStorage.getItem('fullName');

  }

}
