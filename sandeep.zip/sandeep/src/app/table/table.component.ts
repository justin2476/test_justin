import { Component, OnInit } from '@angular/core';
import { SignupService} from '../signup.service'


@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  private newData:any;
  private medops:string="";
  private action:string="";
  private status:string="";
  private comment:string="";
  constructor(private apiService:SignupService) { }

  ngOnInit() {
    this.apiService.getWork().subscribe(data=>this.newData=data)
  }
  myFunction(){

    let obj={medId:this.medops,
    action:this.action,
    status:this.status,
    comment:this.comment
  }
  if(obj)
  {
    this.apiService.postWork(obj).subscribe(()=>this.apiService.getWork().subscribe(data=>this.newData=data) );
  }

console.log(this.action)


  }

}
