import { Component, OnInit } from '@angular/core';

import { SignupService} from '../signup.service'
import {IUser} from '../core/interface';
 
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  private firstName:string="";
  private lastName:string="";
  private adminId:string="";
  private password:string="";
  private mobile:number;
  private repeat:string="";
  public obj:IUser;

  constructor(private signupService: SignupService) { }

  ngOnInit() {
  }
onsubmit(){
  if(this.password==this.repeat)
  {console.log(this.firstName+","+this.lastName+","+this.adminId+","+this.mobile+","+this.repeat+","+this.password);
  let obj={firstName:"",
  lastName:"",
  mobile:0,
  password:"",
  userId:""
};
  if(obj)
  {
   obj.firstName=this.firstName;
    obj.lastName=this.lastName;
    obj.mobile=this.mobile;
   obj.password=this.password;
    obj.userId=this.adminId; 
     console.log( "obj found"+obj ) 

   this.signupService.postUser(obj).subscribe( );
 this.signupService.getWork().subscribe(data=>
  console.log(data) );


  }
  else
  {
    console.log( "no obj found"+obj ) 
  }
}
  else
  console.log("password mismatch");
  }
}
